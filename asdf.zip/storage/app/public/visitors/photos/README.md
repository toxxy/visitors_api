# Carpeta para fotos de visitantes
Esta carpeta almacena las fotos de los visitantes.

Tipos de archivo permitidos:
- JPG, JPEG
- PNG
- GIF
- WebP

Tamaño máximo: 2MB