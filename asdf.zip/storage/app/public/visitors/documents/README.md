# Carpeta para documentos de visitantes
Esta carpeta almacena documentos relacionados con las visitas.

Tipos de archivo permitidos:
- PDF
- DOC, DOCX
- TXT
- JPG, PNG (para documentos escaneados)

Tamaño máximo: 5MB